import logging
import os
from pathlib import Path
import json

from aiohttp import web
from azure.core.credentials import AzureKeyCredential
from azure.identity import AzureDeveloperCliCredential, DefaultAzureCredential
from dotenv import load_dotenv

from ragtools import attach_rag_tools
from rtmt import RTMiddleTier

# Import for direct search access
from azure.search.documents.aio import SearchClient
from azure.search.documents.models import VectorizableTextQuery

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("voicerag")

# Global variables for REST endpoint
rtmt_instance = None
search_client_global = None
search_config = {}


async def query_handler(request):
    """
    REST API endpoint for text queries from Azure Communication Services.
    Uses the same search tools as the realtime voice interface.
    """
    try:
        data = await request.json()
        question = data.get('question', '')
        
        if not question:
            return web.json_response({
                "error": "No question provided"
            }, status=400)
        
        logger.info(f"📩 REST Query received: {question}")
        
        if not search_client_global:
            return web.json_response({
                "error": "Search client not initialized"
            }, status=500)
        
        # Perform search using the same logic as ragtools
        search_results = await perform_search(question)
        
        if search_results and len(search_results) > 0:
            # Format answer with citations
            answer = format_answer(search_results)
            
            return web.json_response({
                "answer": answer,
                "status": "success",
                "question": question,
                "sources": search_results
            })
        else:
            return web.json_response({
                "answer": "I couldn't find relevant information in the knowledge base to answer your question.",
                "status": "success",
                "question": question,
                "sources": []
            })
        
    except Exception as e:
        logger.error(f"❌ Query handler error: {str(e)}")
        import traceback
        traceback.print_exc()
        return web.json_response({
            "error": str(e),
            "status": "error"
        }, status=500)


async def perform_search(query):
    """
    Perform Azure AI Search - same logic as ragtools._search_tool
    """
    try:
        logger.info(f"🔍 Searching for: {query}")
        
        # Build vector query if enabled
        vector_queries = []
        if search_config.get('use_vector_query'):
            vector_queries.append(
                VectorizableTextQuery(
                    text=query,
                    k_nearest_neighbors=5,
                    fields=search_config.get('embedding_field'),
                )
            )
        
        # Execute search
        search_results = await search_client_global.search(
            search_text=query,
            query_type="semantic" if search_config.get('semantic_configuration') else "simple",
            semantic_configuration_name=search_config.get('semantic_configuration'),
            select=[
                search_config.get('identifier_field'),
                search_config.get('content_field')
            ],
            vector_queries=vector_queries,
            top=5,
        )
        
        # Collect results
        results = []
        async for doc in search_results:
            results.append({
                "doc_id": doc.get(search_config.get('identifier_field')),
                "content": doc.get(search_config.get('content_field')),
            })
        
        logger.info(f"✅ Found {len(results)} documents")
        return results
        
    except Exception as e:
        logger.error(f"❌ Search error: {str(e)}")
        import traceback
        traceback.print_exc()
        return []


def format_answer(search_results):
    """
    Format search results into a natural answer with citations
    """
    if not search_results:
        return "I couldn't find relevant information to answer your question."
    
    answer_parts = ["Based on the knowledge base:\n"]
    
    for result in search_results[:3]:  # Top 3 results
        doc_id = result.get('doc_id', 'unknown')
        content = result.get('content', '')
        
        if content:
            # Take first 300 chars
            snippet = content[:300].strip()
            if len(content) > 300:
                snippet += "..."
            
            answer_parts.append(f"{snippet} [source: {doc_id}]")
    
    return "\n\n".join(answer_parts)


async def health_handler(request):
    """Health check endpoint"""
    return web.json_response({
        "status": "healthy",
        "service": "VoiceRAG",
        "version": "1.0.0",
        "endpoints": {
            "/query": "POST - Text queries with RAG",
            "/realtime": "WebSocket - Voice queries with RAG",
            "/health": "GET - Health check"
        },
        "rtmt_initialized": rtmt_instance is not None,
        "search_initialized": search_client_global is not None,
        "model": os.environ.get("AZURE_OPENAI_REALTIME_DEPLOYMENT")
    })


async def create_app():
    global rtmt_instance, search_client_global, search_config

    # Load .env during local dev
    if not os.environ.get("RUNNING_IN_PRODUCTION"):
        logger.info("Running in development mode, loading from .env file")
        load_dotenv()

    llm_key = os.environ.get("AZURE_OPENAI_API_KEY")
    search_key = os.environ.get("AZURE_SEARCH_API_KEY")

    # Determine credential mode
    credential = None
    if not llm_key or not search_key:
        if tenant_id := os.environ.get("AZURE_TENANT_ID"):
            logger.info("Using AzureDeveloperCliCredential with tenant_id %s", tenant_id)
            credential = AzureDeveloperCliCredential(
                tenant_id=tenant_id,
                process_timeout=60
            )
        else:
            logger.info("Using DefaultAzureCredential")
            credential = DefaultAzureCredential()

    llm_credential = AzureKeyCredential(llm_key) if llm_key else credential
    search_credential = AzureKeyCredential(search_key) if search_key else credential

    # -----------------------------
    # Initialize Search Client for REST endpoint
    # -----------------------------
    search_endpoint = os.environ.get("AZURE_SEARCH_ENDPOINT")
    search_index = os.environ.get("AZURE_SEARCH_INDEX")
    
    if search_endpoint and search_index:
        try:
            # Ensure token for managed identity
            if not isinstance(search_credential, AzureKeyCredential):
                search_credential.get_token("https://search.azure.com/.default")
                logger.info("Using DefaultAzureCredential for search")
            
            search_client_global = SearchClient(
                endpoint=search_endpoint,
                index_name=search_index,
                credential=search_credential,
                user_agent="VoiceRAG-REST"
            )
            
            # Store search configuration
            search_config = {
                'semantic_configuration': None,
                'identifier_field': 'id',
                'content_field': 'content',
                'embedding_field': 'contentVector',
                'use_vector_query': (os.getenv("AZURE_SEARCH_USE_VECTOR_QUERY", "true") == "true")
            }
            
            logger.info(f"✅ Search client initialized for REST endpoint")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize search client: {str(e)}")

    # -----------------------------
    # Create Web App
    # -----------------------------
    app = web.Application()

    # -----------------------------
    # Initialize Realtime Middleware (for voice)
    # -----------------------------
    rtmt = RTMiddleTier(
        credentials=llm_credential,
        endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        deployment=os.environ["AZURE_OPENAI_REALTIME_DEPLOYMENT"],
        voice_choice=os.environ.get("AZURE_OPENAI_REALTIME_VOICE_CHOICE") or "alloy"
    )

    rtmt_instance = rtmt

    # -----------------------------
    # System Message (for voice)
    # -----------------------------
    rtmt.system_message = """
You are a RAG assistant.

When the user asks anything factual:
1. ALWAYS call the `search` tool first.
2. ALWAYS call the `report_grounding` tool using the `doc_id` values returned from search.
3. After the grounding tool returns results,
YOU MUST generate a final natural-language answer for the user.

Your final answer MUST:
- Use the content from the grounding tool results.
- Include citations as: [source: DOC_ID]
- Be returned as a normal assistant message (NOT a tool call).

Never stop after grounding. Always send a final answer to the user.
""".strip()

    # -----------------------------
    # Attach RAG Tools (for voice)
    # -----------------------------
    attach_rag_tools(
        rtmt,
        credentials=search_credential,
        search_endpoint=search_endpoint,
        search_index=search_index,
        semantic_configuration=None,
        identifier_field="id",
        content_field="content",
        embedding_field="contentVector",
        title_field="",
        use_vector_query=(os.getenv("AZURE_SEARCH_USE_VECTOR_QUERY", "true") == "true")
    )

    # -----------------------------
    # REST API Routes (NEW!)
    # -----------------------------
    app.router.add_post('/query', query_handler)
    app.router.add_get('/health', health_handler)

    # -----------------------------
    # Attach RTMT to WebSocket Route (for voice)
    # -----------------------------
    rtmt.attach_to_app(app, "/realtime")

    # -----------------------------
    # Static File Serving for UI
    # -----------------------------
    current_directory = Path(__file__).parent
    app.add_routes([web.get('/', lambda _: web.FileResponse(current_directory / 'static/index.html'))])
    app.router.add_static('/', path=current_directory / 'static', name='static')

    return app


if __name__ == "__main__":
    host = "localhost"
    port = 8765
    logger.info("=" * 70)
    logger.info("🚀 VoiceRAG Server Starting")
    logger.info("=" * 70)
    logger.info(f"🎤 Voice (WebSocket): ws://{host}:{port}/realtime")
    logger.info(f"💬 Text (REST API):   http://{host}:{port}/query")
    logger.info(f"💚 Health Check:      http://{host}:{port}/health")
    logger.info(f"🌐 Web UI:            http://{host}:{port}/")
    logger.info(f"🤖 Model:             {os.environ.get('AZURE_OPENAI_REALTIME_DEPLOYMENT')}")
    logger.info("=" * 70)
    web.run_app(create_app(), host=host, port=port)
